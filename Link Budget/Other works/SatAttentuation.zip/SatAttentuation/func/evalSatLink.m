function [ PRX PRXdBW L G CtoN0 A_ox A_wv A_cloud A_rain ] = evalSatLink( Long, lat, frq, diamEarth, satel3dB, polangel, depolEarth, depolSat, effEarth, effSat, PTX, LFEarthX, LFSatX, Elevation, RR, transmission, LWC, Rel_hum, Feeder_temp, Rec_temp  )
%This program calculates the total received power in an earth-satellite
%up/downlink GEO network. Using certain parameters the total
%loss/attenuation in the link is calculated using the loss() function, then
%the gain of both the satellite & earth station is found using gain(). The total
%received power is then calculated using powerrec().
%
% Input arguments include"
%   1)Long - earth station longitude relative to satellite (degrees)
%   2)lat  - earth station latitude (degrees)
%   3)frq  - carrier frequency (GHZ)
%   4)diamEarth - earth antenna diameter (m)
%   5)satel3dB  - satellite antenna 3dB angle (degrees)
%   6)polangel  - receiver polarization mismatch angle (degrees)
%   7)depolEarth - earth depolarization angle (degrees)
%   8)depolSat   - sat        =           =       =    
%   8)effEarth   - efficiency of earth antenna (0<e<1)
%   9)effSat     -     =      =  sat      =       =   
%   10)PTX       - transmitted power before feeder (W)
%   11)LFEarthX  - earth station equipment loss (dB)
%   12)LFSatX    - Satellite        =        =    = 
%   13)Elevation - Elevation angle from ground (deg)
%   14)RR        - Rainfall rate in (mm/h)
%   15)transmission - string either 'uplink' or 'downlink'
%   16)LWC       - cloud Liquid Water Content in (mm/m^3)
%   17)Rel_hum   - Relative Humidity at earth station
%   18)Feeder_temp - temperature of feeder in K
%   19)Rec_remp  - temperature of receiver in K
% Earth-satellite link performance is evaluated by the C/N0 ratio of the
% received signal. If this ratio is too small the signal power is less than that of noise,
% which deems the signal undetectable. Given certain parameters & the
% transmitted power, this program calculates the total received power given
% losses due to:
%   a) Free space loss (LFS)
%   b) Atmospheric loss (LA)
%   c) Transmitter depointing loss (LT), d) Receiver depointing loss (LR)
%   e) Polarization mismatch loss (LPOL), & finally 
%   f) Losses in the transmitting (LFTX) & receiving equipment (LFRX).
%   Particularly the feeder loss between transmitter & antenna (LFTX),
%   or antenna & the receiver.
% The gain of the link takes into account the satellite 3dB angle given by
% the user, and the diameter of the earth station antenna, from which the
% 3dB angle of the earth station is approximately found. Other variables
% taken into account include antenna efficiencies, & depolarization angles.
% The power is found by taking into account all the losses and the total
% gain of the link.
%
% outputs include: 
%   a) PRX - column vector of received power after feeder - p(1) is the total power
%      taking into account all losses; p(2) ignoring equipment loss; p(3)
%      ignoring depointing losses; p(4) only free space loss.

globals(frq, diamEarth, RR, Elevation, LWC, Rel_hum, Feeder_temp, Rec_temp );

% ~~ main ~~ %

global earth3dB;

[ L Lrain LFRX A_ox A_wv A_cloud A_rain ] = loss( Long, lat, depolEarth, depolSat, earth3dB, satel3dB, polangel, LFEarthX, LFSatX, Elevation, transmission );
[ G ] = gain( effEarth, effSat, satel3dB, transmission );
[ PRX PRXdBW ] = powerrec( PTX, L, G(1), G(2) );
CtoN0 = CtoN0Ratio( PTX, L, Lrain, LFRX, G );

return

end

