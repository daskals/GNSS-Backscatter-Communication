function [ PRX PRXdBW EIRP ] = powerrec( PTX, L, GTmax, GRmax )
%Received power PR & PRdBW are column vectors with each value depending on
%the losses accounted for. E.g., if PR = [1;2;3;4], the first value is the
%power when all losses are considered, 2nd is when equipment loss is
%ignored, etc.

EIRP = 10*log10(PTX) + GTmax;        % EIRP(dBW) = PT(dBW) + GT(dB)
PRXdBW = EIRP + GRmax - L;           % received power vector, for vector valued L in dBW
PRX = 10.^(PRXdBW/10);               

%10*log10(PR) = PRdBW => PRdBW/10 = log10(PR) => 10^(PRdBW/10) = PR;

end

