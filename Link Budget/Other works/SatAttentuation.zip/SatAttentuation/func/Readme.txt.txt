This folder contains all the raw functions.
it should contain:
atmAttenuation
CtoN0Ratio
gain
globals
loss
powerrec
satGUInew
test