function [  ] = globals( frq, diamEarth, RR, Elevation, LWC, Rel_hum, Feeder_temp, Rec_temp  )

% ~~ Global constants ~~ %

global c R0 k kdB rainRate E rh0 rlwc TF TeRX;

E = Elevation;
R0 = 35786e3;                                       %GEO orbit distance
c = 3e8;                                            %Speed of light
k = 1.379*10^-32;
kdB = -228.6;                                       %Boltzmann constant
rainRate = RR;
rh0 = Rel_hum;
rlwc = LWC;
TF = Feeder_temp;
TeRX = Rec_temp;

% ~~ variables ~~ %

global f D;                                         %User defined
global WL earth3dB;                                 %Program required

f = frq;                                            %f in GHz
fHz = f*1e9;                                        %fcy in Hz
WL = c/fHz;                                         %Wavelength
D = diamEarth;                                      

earth3dB = 70*WL/D;                                 %Three dB angle of transmitter

return

end