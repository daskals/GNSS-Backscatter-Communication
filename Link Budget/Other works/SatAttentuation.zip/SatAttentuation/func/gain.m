function [ G ] = gain( effEarth, effSat, sat3dB, transmission )
%Gain inputs effEarch, effSat, earth3dB, sat3dB, depolEarth, depolSat,
%transmission; outputs vector G = [GTmax GRmax]
%
%   GT/GR: gain taking into account depointing.
%   GTmax/GRmax: ignoring depointing.
%   actual gain G is related to receiving equipment loss LR, LFRX
global f D c;

fHz = f*10^9;    %convert f in Hertz

G_earthmax = 10*log10(effEarth*(pi*D*fHz/c)^2); 
G_satmax = 10*log10(effSat*(pi*70/sat3dB)^2);     %maximum dBi gain of trans. & rec. antennas

if strcmpi(transmission, 'Uplink')
    GTmax = G_earthmax;
    GRmax = G_satmax;
elseif strcmpi(transmission, 'Downlink')
    GTmax = G_satmax;
    GRmax = G_earthmax;
else error('myApp:argChk', 'Transmission input must be either Uplink or Downlink')
end

G = [GTmax GRmax];

return

end

