function varargout = satGUInew(varargin)
% SATGUINEW M-file for satGUInew.fig
%      SATGUINEW, by itself, creates a new SATGUINEW or raises the existing
%      singleton*.
%
%      H = SATGUINEW returns the handle to a new SATGUINEW or the handle to
%      the existing singleton*.
%
%      SATGUINEW('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in SATGUINEW.M with the given input arguments.
%
%      SATGUINEW('Property','Value',...) creates a new SATGUINEW or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before satGUInew_OpeningFcn gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to satGUInew_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run_input_data (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help satGUInew

% Last Modified by GUIDE v2.5 27-Apr-2011 00:43:03

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @satGUInew_OpeningFcn, ...
                   'gui_OutputFcn',  @satGUInew_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before satGUInew is made visible.
function satGUInew_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to satGUInew (see VARARGIN)
handles.flag = 1;
set(handles.plot_x_name, 'String', 'L [dB]');
set(handles.plot_y_name, 'String', 'C/N0 [dB]');

%sample data standard values
handles.ASTRA_FREQ = '12';
handles.DIAMEARTH = '4';
handles.ASTRA_3DB = '2';
handles.POLANGEL = '0';
handles.DEPOLEARTH = '0';
handles.DEPOLSAT = '0';
handles.EARTH_EFF = '0.6';
handles.SAT_EFF = '0.55';
handles.POWER_T = '100';
handles.TRANSMISSION = 'Uplink';
handles.LFEARTHX = '0.5';
handles.LFSATX = '1';
handles.FEEDER_TEMP = '290';
handles.RECEIV_TEMP = '50';
handles.CITY_LONG = '35.10';
handles.CITY_LAT = '33.2';
handles.ASTRA_ELEVATION = '45.38';

handles.NICOSIA_RR = 400/(365*24); %in mm/h
handles.PARIS_RR = 641/(365*24);
handles.NYC_RR = 1200/(365*24);

handles.CITY_RR = num2str(handles.NICOSIA_RR);  %SET DEFAULT TO NICOSIA
handles.CITY_LWC = '0.03';                  
handles.CITY_REL_HUMID = '0.65';

% Choose default command line output for satGUInew
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes satGUInew wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = satGUInew_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



function Long_lat_Callback(hObject, eventdata, handles)
% hObject    handle to Long_lat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Long_lat as text
%        str2double(get(hObject,'String')) returns contents of Long_lat as a double
long_lat = get(hObject,'String');
s=long_lat;
size = length(s);
if size > 7
    error('myApp:argChk', 'Longitude, latitude must be a pair: e.g. (2,90),(22,10).. etc')
end

%find ( , and ) 
for i=1:size
    if s(i)=='(';
        flaglp = i;
    elseif s(i)==','
        flagc = i;
    elseif s(i)==')'
        flagrp = i;
    end
end
if flagc-flaglp == 2
    long = str2double( s(flaglp+1) );
elseif flagc-flaglp == 3
    long = str2double( [s(flaglp+1) s(flaglp+2)] );
end
if flagrp-flagc == 2
    lat = str2double( s(flagc+1) );
elseif flagrp-flagc == 3
    lat = str2double( [s(flagc+1) s(flagc+2)] );
end

%make sure not empty
if (isempty(s))
     set(hObject,'String','0')
end

guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function Long_lat_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Long_lat (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function freq_Callback(hObject, eventdata, handles)
% hObject    handle to freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of freq as text
%        str2double(get(hObject,'String')) returns contents of freq as a double

f = str2double(get(hObject,'String'));

if (isempty(f))
     set(hObject,'String','0')
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function freq_CreateFcn(hObject, eventdata, handles)
% hObject    handle to freq (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function diamEarthStation_Callback(hObject, eventdata, handles)
% hObject    handle to diamEarthStation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of diamEarthStation as text
%        str2double(get(hObject,'String')) returns contents of diamEarthStation as a double
diamEarth = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(diamEarth))
     set(hObject,'String','0')
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function diamEarthStation_CreateFcn(hObject, eventdata, handles)
% hObject    handle to diamEarthStation (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function sat3dBAngle_Callback(hObject, eventdata, handles)
% hObject    handle to sat3dBAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of sat3dBAngle as text
%        str2double(get(hObject,'String')) returns contents of sat3dBAngle as a double
sat3dB = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(sat3dB))
     set(hObject,'String','0')
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function sat3dBAngle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to sat3dBAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function antennaPolarizAngle_Callback(hObject, eventdata, handles)
% hObject    handle to antennaPolarizAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of antennaPolarizAngle as text
%        str2double(get(hObject,'String')) returns contents of antennaPolarizAngle as a double
polangel = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(polangel))
     set(hObject,'String','0')
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function antennaPolarizAngle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to antennaPolarizAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EarthDepolAngle_Callback(hObject, eventdata, handles)
% hObject    handle to EarthDepolAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EarthDepolAngle as text
%        str2double(get(hObject,'String')) returns contents of EarthDepolAngle as a double
depolEarth = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(depolEarth))
     set(hObject,'String','0')
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function EarthDepolAngle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EarthDepolAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function SatDepolAngle_Callback(hObject, eventdata, handles)
% hObject    handle to SatDepolAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SatDepolAngle as text
%        str2double(get(hObject,'String')) returns contents of SatDepolAngle as a double
depolSat = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(depolSat))
     set(hObject,'String','0')
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function SatDepolAngle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SatDepolAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Run_input_data.
function Run_input_data_Callback(hObject, eventdata, handles)
% hObject    handle to Run_input_data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

%get variables
%get longitude, latitude

format short eng;

long_lat = get(handles.Long_lat,'String');
s=long_lat;
size = length(s);
if size > 7
    error('myApp:argChk', 'Longitude, latitude must be a pair: e.g. (2,90),(22,10).. etc')
end
%find ( , and ) 
for i=1:size
    if s(i)=='(';
        flaglp = i;
    elseif s(i)==','
        flagc = i;
    elseif s(i)==')'
        flagrp = i;
    end
end
if flagc-flaglp == 2
    Long = str2double( s(flaglp+1) );
elseif flagc-flaglp == 3
    Long = str2double( [s(flaglp+1) s(flaglp+2)] );
end
if flagrp-flagc == 2
    lat = str2double( s(flagc+1) );
elseif flagrp-flagc == 3
    lat = str2double( [s(flagc+1) s(flagc+2)] );
end

frq = str2double(get(handles.freq,'String'));
diamEarth = str2double(get(handles.diamEarthStation,'String'));
satel3dB = str2double(get(handles.sat3dBAngle,'String'));
polangel = str2double(get(handles.antennaPolarizAngle,'String'));
depolEarth = str2double(get(handles.EarthDepolAngle,'String'));
depolSat = str2double(get(handles.SatDepolAngle,'String'));
effEarth = str2double(get(handles.EarthAntennaEff,'String'));
effSat = str2double(get(handles.SatAntennaEff,'String'));
PTX = str2double(get(handles.InputPower,'String'));
LFEarthX = str2double(get(handles.EarthFeederLoss,'String'));
LFSatX = str2double(get(handles.SatFeederLoss,'String'));
Elevation =  str2double(get(handles.ElevationAngle,'String'));
RR =  str2double(get(handles.RainRate,'String'));
LWC = str2double(get(handles.LWC_edit_text,'String'));
Rel_hum = str2double(get(handles.RH_edit,'String'));
Feeder_temp = str2double(get(handles.Feeder_temp_edit,'String'));
Rec_temp = str2double(get(handles.Rec_temp_edit,'String'));


if (get(handles.UplinkRadioButton,'Value') == get(hObject,'Max'))
	transmission = 'Uplink';
elseif (get(hObject,'Value') == get(hObject,'Max'))
	transmission = 'Downlink';
end

[PRX PRXdBW L G CtoN0 A_ox A_wv A_cloud A_rain] = evalSatLink( Long, lat, frq, diamEarth, satel3dB, polangel, depolEarth, depolSat, effEarth, effSat, PTX, LFEarthX, LFSatX, Elevation, RR, transmission, LWC, Rel_hum, Feeder_temp, Rec_temp );

PRXdBW = roundn(PRXdBW,-2);
L = roundn(L,-2);
G = roundn(G,-2);

handles.A_ox = num2str(A_ox);
handles.A_wv = num2str(A_wv);
handles.A_cloud = num2str(A_cloud);
handles.A_rain = num2str(A_rain);       %attenuation vs height

handles.PRXdBW = num2str(PRXdBW);
handles.L = num2str(L);
G = num2str(G);
handles.CtoN0 = num2str(CtoN0);
handles.current_data = handles.CtoN0;   %set default plot CtoN0

set(handles.PowerReceiveddBW,'String',handles.PRXdBW);
set(handles.Losses,'String',handles.L);
set(handles.Gain_max,'String',G);
set(handles.CarriertoNoise,'String',handles.CtoN0);

guidata(hObject, handles);

% --- Executes on button press in ClearAll.
function ClearAll_Callback(hObject, eventdata, handles)
% hObject    handle to ClearAll (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
set(handles.Long_lat,'String','(0,0)');
set(handles.freq,'String','0');
set(handles.diamEarthStation,'String','0');
set(handles.sat3dBAngle,'String','0');
set(handles.antennaPolarizAngle,'String','0');
set(handles.EarthDepolAngle,'String','0');
set(handles.SatDepolAngle,'String','0');
set(handles.EarthAntennaEff,'String','0');
set(handles.SatAntennaEff,'String','0');
set(handles.InputPower,'String','0');
set(handles.EarthFeederLoss,'String','0');
set(handles.SatFeederLoss,'String','0');
set(handles.ElevationAngle,'String','0');
set(handles.RainRate,'String','0');
set(handles.LWC_edit_text,'String','0');
set(handles.RH_edit,'String','0');
set(handles.Feeder_temp_edit,'String','0');
set(handles.Rec_temp_edit,'String','0');
set(handles.CarriertoNoise,'String','0');
set(handles.PowerReceiveddBW,'String','0');
set(handles.Losses,'String','0');
set(handles.Gain_max,'String','0');
guidata(hObject, handles);


% --- Executes on button press in Exit.
function Exit_Callback(hObject, eventdata, handles)
% hObject    handle to Exit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
close(handles.figure1);

function SatAntennaEff_Callback(hObject, eventdata, handles)
% hObject    handle to SatAntennaEff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SatAntennaEff as text
%        str2double(get(hObject,'String')) returns contents of SatAntennaEff as a double
effSat = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(effSat))
     set(hObject,'String','0')
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function SatAntennaEff_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SatAntennaEff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EarthAntennaEff_Callback(hObject, eventdata, handles)
% hObject    handle to EarthAntennaEff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EarthAntennaEff as text
%        str2double(get(hObject,'String')) returns contents of EarthAntennaEff as a double
effEarth= str2double(get(hObject,'String'));

%make sure not empty
if (isempty(effEarth))
     set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function EarthAntennaEff_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EarthAntennaEff (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function InputPower_Callback(hObject, eventdata, handles)
% hObject    handle to InputPower (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of InputPower as text
%        str2double(get(hObject,'String')) returns contents of InputPower as a double
PTX = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(PTX))
     set(hObject,'String','0')
end
guidata(hObject, handles);


% --- Executes during object creation, after setting all properties.
function InputPower_CreateFcn(hObject, eventdata, handles)
% hObject    handle to InputPower (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function EarthFeederLoss_Callback(hObject, eventdata, handles)
% hObject    handle to EarthFeederLoss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of EarthFeederLoss as text
%        str2double(get(hObject,'String')) returns contents of EarthFeederLoss as a double
LFEarthX = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(LFEarthX))
     set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function EarthFeederLoss_CreateFcn(hObject, eventdata, handles)
% hObject    handle to EarthFeederLoss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function SatFeederLoss_Callback(hObject, eventdata, handles)
% hObject    handle to SatFeederLoss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of SatFeederLoss as text
%        str2double(get(hObject,'String')) returns contents of SatFeederLoss as a double
LFSatX = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(LFSatX))
     set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function SatFeederLoss_CreateFcn(hObject, eventdata, handles)
% hObject    handle to SatFeederLoss (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ElevationAngle_Callback(hObject, eventdata, handles)
% hObject    handle to ElevationAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of ElevationAngle as text
%        str2double(get(hObject,'String')) returns contents of ElevationAngle as a double
Elevation = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(Elevation))
     set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function ElevationAngle_CreateFcn(hObject, eventdata, handles)
% hObject    handle to ElevationAngle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function RainRate_Callback(hObject, eventdata, handles)
% hObject    handle to RainRate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RainRate as text
%        str2double(get(hObject,'String')) returns contents of RainRate as a double
RR = str2double(get(hObject,'String'));

%make sure not empty
if (isempty(RR))
     set(hObject,'String','0')
end
guidata(hObject, handles);

% --- Executes during object creation, after setting all properties.
function RainRate_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RainRate (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in UplinkRadioButton.
function UplinkRadioButton_Callback(hObject, eventdata, handles)
% hObject    handle to UplinkRadioButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of UplinkRadioButton
if (get(hObject,'Value') == get(hObject,'Max'))
	transmission = 'Uplink';
end
guidata(hObject, handles);

% --- Executes on button press in DownlinkRadioButton.
function DownlinkRadioButton_Callback(hObject, eventdata, handles)
% hObject    handle to DownlinkRadioButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of DownlinkRadioButton
if (get(hObject,'Value') == get(hObject,'Max'))
	transmission = 'Downlink';
end
guidata(hObject, handles);


function CarriertoNoise_Callback(hObject, eventdata, handles)
% hObject    handle to CarriertoNoise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of CarriertoNoise as text
%        str2double(get(hObject,'String')) returns contents of CarriertoNoise as a double


% --- Executes during object creation, after setting all properties.
function CarriertoNoise_CreateFcn(hObject, eventdata, handles)
% hObject    handle to CarriertoNoise (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PowerReceived_Callback(hObject, eventdata, handles)
% hObject    handle to PowerReceived (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PowerReceived as text
%        str2double(get(hObject,'String')) returns contents of PowerReceived as a double


% --- Executes during object creation, after setting all properties.
function PowerReceived_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PowerReceived (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function PowerReceiveddBW_Callback(hObject, eventdata, handles)
% hObject    handle to PowerReceiveddBW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of PowerReceiveddBW as text
%        str2double(get(hObject,'String')) returns contents of PowerReceiveddBW as a double


% --- Executes during object creation, after setting all properties.
function PowerReceiveddBW_CreateFcn(hObject, eventdata, handles)
% hObject    handle to PowerReceiveddBW (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function Losses_Callback(hObject, eventdata, handles)
% hObject    handle to Losses (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Losses as text
%        str2double(get(hObject,'String')) returns contents of Losses as a double


% --- Executes during object creation, after setting all properties.
function Losses_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Losses (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function Gain_max_Callback(hObject, eventdata, handles)
% hObject    handle to Gain_max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Gain_max as text
%        str2double(get(hObject,'String')) returns contents of Gain_max as a double


% --- Executes during object creation, after setting all properties.
function Gain_max_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Gain_max (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in popupmenu1.
function popupmenu1_Callback(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns popupmenu1 contents as cell array
%        contents{get(hObject,'Value')} returns selected item from popupmenu1
handles.popup_str = cellstr(get(hObject, 'String'));
handles.popup_val = handles.popup_str{get(hObject,'Value')};
switch handles.popup_val;
    case 'C/N0 vs L' % User selects peaks
        handles.current_data = handles.CtoN0;
        handles.flag = 1;
        set(handles.plot_x_name, 'String', 'Loss [dB]');
        set(handles.plot_y_name, 'String', 'Carrier to noise [dBHZ]');
    case 'PRXdBW vs L' % User selects membrane
        handles.current_data = handles.PRXdBW;
        handles.flag = 1;
        set(handles.plot_x_name, 'String', 'Loss [dB]');
        set(handles.plot_y_name, 'String', 'Received power [dBW]');        
    case 'A_ox vs h'
        handles.h = 0:0.0001:30;
        handles.current_data = handles.A_ox;
        handles.flag = 0;
        set(handles.plot_x_name, 'String', 'Height [km]');
        set(handles.plot_y_name, 'String', 'Oxygen attenuation [dB/km]');        
    case 'A_wv vs h'
        handles.h = 0:0.0001:2;    %height of wv does not exceed 2km
        handles.current_data = handles.A_wv;
        handles.flag = 0;
        set(handles.plot_x_name, 'String', 'Height [km]');
        set(handles.plot_y_name, 'String', 'Water vapor attenuation [dB/km]');        
    case 'A_rain vs h'
        handles.h = 0:0.0001:2;    %height of wv does not exceed 2km
        handles.current_data = handles.A_rain;
        handles.flag = 0;
        set(handles.plot_x_name, 'String', 'Height [km]');
        set(handles.plot_y_name, 'String', 'Rain attenuation [dB/km]');        
    case 'A_cloud vs h'
        handles.h = 0:0.0001:0.36;  %cloud thickness 0.36km
        handles.current_data = handles.A_cloud;
        handles.flag = 0;
        set(handles.plot_x_name, 'String', 'Height [km]');
        set(handles.plot_y_name, 'String', 'Cloud attenuation [dB/km]');        
end

guidata(hObject,handles)


% --- Executes during object creation, after setting all properties.
function popupmenu1_CreateFcn(hObject, eventdata, handles)
% hObject    handle to popupmenu1 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in Plot_pushButton.
function Plot_pushButton_Callback(hObject, eventdata, handles)
% hObject    handle to Plot_pushButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
plot_y_data = str2num(handles.current_data);
if handles.flag
    L = str2num(handles.L);    
    plot_y_data = str2num(handles.current_data);
    plot(L,plot_y_data);
elseif ~handles.flag
    plot(handles.h,plot_y_data);
end
guidata(hObject, handles);



function LWC_edit_text_Callback(hObject, eventdata, handles)
% hObject    handle to LWC_edit_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of LWC_edit_text as text
%        str2double(get(hObject,'String')) returns contents of LWC_edit_text as a double


% --- Executes during object creation, after setting all properties.
function LWC_edit_text_CreateFcn(hObject, eventdata, handles)
% hObject    handle to LWC_edit_text (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function RH_edit_Callback(hObject, eventdata, handles)
% hObject    handle to RH_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of RH_edit as text
%        str2double(get(hObject,'String')) returns contents of RH_edit as a double


% --- Executes during object creation, after setting all properties.
function RH_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to RH_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Rec_temp_edit_Callback(hObject, eventdata, handles)
% hObject    handle to Rec_temp_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Rec_temp_edit as text
%        str2double(get(hObject,'String')) returns contents of Rec_temp_edit as a double


% --- Executes during object creation, after setting all properties.
function Rec_temp_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Rec_temp_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function Feeder_temp_edit_Callback(hObject, eventdata, handles)
% hObject    handle to Feeder_temp_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of Feeder_temp_edit as text
%        str2double(get(hObject,'String')) returns contents of Feeder_temp_edit as a double


% --- Executes during object creation, after setting all properties.
function Feeder_temp_edit_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Feeder_temp_edit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in Sample_list_box.
function Sample_list_box_Callback(hObject, eventdata, handles)
% hObject    handle to Sample_list_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: contents = cellstr(get(hObject,'String')) returns Sample_list_box contents as cell array
%        contents{get(hObject,'Value')} returns selected item from Sample_list_box
str = cellstr(get(hObject,'String'));
val = str{get(hObject,'Value')};
if strcmp(val,'Nicosia')
    handles.CITY_LONG = '35.10';
    handles.CITY_LAT = '33.2';
    handles.CITY_RR = num2str(handles.NICOSIA_RR);
    handles.CITY_LWC = '0.03';
    handles.CITY_REL_HUMID = '0.65';
elseif strcmp(val,'Paris')    
    handles.CITY_LONG = '48.52';
    handles.CITY_LAT = '2.20';
    handles.CITY_RR = num2str(handles.PARIS_RR);
    handles.CITY_LWC = '0.09';
    handles.CITY_REL_HUMID = '0.75';
elseif strcmp(val,'New York City');
    handles.CITY_LONG = '41.84';
    handles.CITY_LAT = '73.59';
    handles.CITY_RR = num2str(handles.NYC_RR);
    handles.CITY_LWC = '0.12';
    handles.CITY_REL_HUMID = '0.72';
end
guidata(hObject, handles);    


% --- Executes during object creation, after setting all properties.
function Sample_list_box_CreateFcn(hObject, eventdata, handles)
% hObject    handle to Sample_list_box (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: listbox controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in ASTRA_toggle.
function ASTRA_toggle_Callback(hObject, eventdata, handles)
% hObject    handle to ASTRA_toggle (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ASTRA_toggle


% --- Executes on button press in Run_sample_data.
function Run_sample_data_Callback(hObject, eventdata, handles)
% hObject    handle to Run_sample_data (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
CITY_LONG = str2double(handles.CITY_LONG);
CITY_LAT = str2double(handles.CITY_LAT);
CITY_RR = str2double(handles.CITY_RR);
CITY_LWC = str2double(handles.CITY_LWC);
CITY_REL_HUMID = str2double(handles.CITY_REL_HUMID);
ASTRA_ELEVATION = str2double(handles.ASTRA_ELEVATION);
ASTRA_FREQ = str2double(handles.ASTRA_FREQ);
DIAMEARTH = str2double(handles.DIAMEARTH);
ASTRA_3DB = str2double(handles.ASTRA_3DB);
POLANGEL = str2double(handles.POLANGEL);
DEPOLEARTH = str2double(handles.DEPOLEARTH);
DEPOLSAT = str2double(handles.DEPOLSAT);
EARTH_EFF = str2double(handles.EARTH_EFF);
SAT_EFF = str2double(handles.SAT_EFF);
POWER_T = str2double(handles.POWER_T);
LFEARTHX = str2double(handles.LFEARTHX);
LFSATX = str2double(handles.LFSATX);
FEEDER_TEMP = str2double(handles.FEEDER_TEMP);
RECEIV_TEMP = str2double(handles.RECEIV_TEMP);
TRANSMISSION = handles.TRANSMISSION;

[PRX PRXdBW L G CtoN0 A_ox A_wv A_cloud A_rain] = evalSatLink( CITY_LONG, CITY_LAT, ASTRA_FREQ, DIAMEARTH, ASTRA_3DB, POLANGEL, DEPOLEARTH, DEPOLSAT, EARTH_EFF, SAT_EFF, POWER_T, LFEARTHX, LFSATX, ASTRA_ELEVATION, CITY_RR, TRANSMISSION, CITY_LWC, CITY_REL_HUMID, FEEDER_TEMP, RECEIV_TEMP );

PRXdBW = roundn(PRXdBW,-2);
L = roundn(L,-2);
G = roundn(G,-2);

handles.A_ox = num2str(A_ox);
handles.A_wv = num2str(A_wv);
handles.A_cloud = num2str(A_cloud);
handles.A_rain = num2str(A_rain);       %attenuation vs height

handles.PRXdBW = num2str(PRXdBW);
handles.L = num2str(L);
G = num2str(G);
handles.CtoN0 = num2str(CtoN0);
handles.current_data = handles.CtoN0;   %set default plot CtoN0

set(handles.PowerReceiveddBW,'String',handles.PRXdBW);
set(handles.Losses,'String',handles.L);
set(handles.Gain_max,'String',G);
set(handles.CarriertoNoise,'String',handles.CtoN0);

guidata(hObject, handles);


% --- Executes on button press in First_ASTRA_pushbutton.
function First_ASTRA_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to First_ASTRA_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.ASTRA_ELEVATION = '45.38';
guidata(hObject, handles);


% --- Executes on button press in Second_ASTRA_pushbutton.
function Second_ASTRA_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to Second_ASTRA_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.ASTRA_ELEVATION = '46.77';
guidata(hObject, handles);


% --- Executes on button press in Third_ASTRA_pushbutton.
function Third_ASTRA_pushbutton_Callback(hObject, eventdata, handles)
% hObject    handle to Third_ASTRA_pushbutton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
handles.ASTRA_ELEVATION = '47.74';
guidata(hObject, handles);
