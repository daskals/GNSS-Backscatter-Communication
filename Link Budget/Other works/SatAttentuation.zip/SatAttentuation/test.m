%Test script
% 
% [PRX PRXdBW L G CtoN0] = evalSatLink(0,0,14,4,2,1,0.1,0.2,0.6,0.55,100,0.3,0.2,20,0.5,'uplink');

%[LFS LT LR L, GTmax GT GRmax GR] = main(0,0,12e9,4,2,0,0,0,0.6,0.55,'downlink');  % ex 2

% [LFS LT LR L, GTmax GT GRmax GR] = main(0,0,14.2e9,4.6,2.1,0,0,0,0.64,0.53,'uplink');  % prob 1

% [PR PRdBW L G] = main(0,0,14.2e9,4,2.1,0.1,0.1,0.2,0.6,0.55,10,2,2,'downlink');  % prob 2

% [PRX PRXdBW L G CtoN0] = main(0,0,14,4,2,0,0.1,1,0.6,0.55,100,0.5,1,10,0.1,'uplink');

%[PRX PRXdBW L G CtoN0]=evalSatLink(0,0,14,4,2,0,0,0,0.6,0.55,100,0,0,0,0,'Uplink',0,0,0,0);

%example 1a: Uplink (clear sky) LA=.3,E=10

[PRX PRXdBW L G CtoN0]=evalSatLink(0,0,14,4,2,0,.1,0,0.6,0.55,100,0.5,1.3,10,0,'Uplink',0,0,290,290)
