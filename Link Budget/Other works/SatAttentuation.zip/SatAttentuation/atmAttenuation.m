function [ A_ox A_wv A_cloud A_rain ] = atmAttenuation( ~ )

% ~~ LA will be calculated using JPL/DSN model (by NASA) & US standard atmospheric temp ~~ %
%oxygen attenuation, a(h,f):

global f rainRate h0 rh0 rlwc;
MSLP = 1013.25;                    %Mean Sea Level Pressure in mbar 
h0 = 1;                            %assume earth station 0km (sea level)
Ph0 = MSLP;                        %earth station pressure = MSLP
Tp = 290;                          %assume uniform temperature at any hight h in kelvin
Th0 = 290;                         %assume 22 degree celcius at earth station height
%first we must warn user that this model (precisely the oxygen attenuation)
%is valid for fcies up to 45GHz

if f>45
    warning('The atmospheric attentuation model is good for f<=45 GHz)');
end

C = 0.011*(7.13e-7*f^4-9.2051e-5*f^3+3.280422e-3*f^2-0.01906468*f+1.110303146); %very good model for f<45GHz

h = 0:0.0001:30;
P = Ph0*exp(8.387*(h0-h)./((8.387-0.0887*h0)*(8.387-0.0887*h)));  %pressure versus height. Assuming global mean pressure @ sea level as measured by NASA

gamma0(length(P)) = 0;

for i=1:length(P)
    if P(i)>333
        gamma0(i) = 0.59;
    elseif P(i)>25 && P(i)<=333
        gamma0(i) = 0.59*(1+0.0031*(333-P(i)));
    elseif P(i)<=25
        gamma0(i) = 1.18;
    end
end

gamma = gamma0.*(P/1013)*(300/Tp)^0.85;

A_ox = C*gamma0*f^2.*(P/1013).^2*(300/Tp)^2.85.*(1./((f-60)^2+gamma.^2)+1./(f^2+gamma.^2));  %attenuation of o2 in dB/km

%water vapor attenuation

Hwv = 2;           %scaled height of water vapor--set to 2 km.
h = 0:0.0001:2;    %height of wv does not exceed 2km
rwvh0 = (1320.65/Th0)*rh0*10^(7.4475*(Th0 - 273.14)/Th0);

rwv = rwvh0.*exp(h/Hwv); %absolute humidity

gamma1(length(h)) = 0;
for i =1:length(h)          %loop necessary bc we need only pressure 0-2km
    gamma1(i) = 2.85*(P(i)/1013)*(300/Tp)^0.626.*(1+0.018*rwv(i)*Tp/P(i));
end

kwv = 2*f^2*rwv*(300/Tp)^1.5.*gamma1;

dwv = (22.2^2-f^2)^2+4*f^2*gamma1.^2;

a_wv = (300./(Tp*dwv)).*exp(-644/Tp);

A_wv = kwv.*(a_wv+1.2e-6);    %final expression for attenuation of water vapor

%rain attenuation model

A_rain(length(h))=0;    %assume rain is 2km high

for i=1:length(h)
    if f<=2.9
        A_rain(i) = 6.39e-5*f^2.03;
    elseif f>2.9 && f<=54              
        A_rain(i) = 4.21e-5*f^2.42;
    end
end

if f<=8.5
    B_rain = 0.851*f^0.158;
elseif f>8.85 && f<=25
    B_rain = 1.41*f^-0.0779;
elseif f>25 &&  f<164
    B_rain = 2.65*f^-0.272;
end

A_rain = A_rain*rainRate^B_rain;

%cloud attenuation

% rlwc = 0.5;     %take liquid water content = 0.5 g/m^3

h = 0:0.0001:0.36;  %cloud thickness 0.36km
A_cloud(length(h)) = 0;
for i = 1:length(h)
    A_cloud(i) = rlwc*f^1.95*exp(1.5735-0.0309*Tp);
end

end

