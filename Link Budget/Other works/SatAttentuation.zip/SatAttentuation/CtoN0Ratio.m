function [ CtoN0 ] = CtoN0Ratio( PTX, L, Lrain, LFRX, G )
%CTON0RATIO Summary of this function goes here
%   Detailed explanation goes here

global f E kdB TF TeRX;

% EIRPTX = EIRP - LT - LFTX;

GRmax = G(2);
GTmax = G(1);

if f <= 17.5
    if E >= 0 && E < 5
        TSKY = 200;
    elseif E >= 5 && E < 10
        TSKY = 60;
    elseif E >= 10 && E < 20
        TSKY = 50;
    elseif E >= 20 && E < 30
        TSKY = 25;
    elseif E >= 30 && E < 60
        TSKY = 18;
    elseif E >=60 && E <= 90
        TSKY = 10;
    end
elseif f > 17.5 && f <= 30
    if E >= 0 && E < 5
        TSKY = 300;
    elseif E >= 5 && E < 10
        TSKY = 180;
    elseif E >= 10 && E < 20
        TSKY = 125;
    elseif E >= 20 && E < 30
        TSKY = 70;
    elseif E >= 30 && E < 60
        TSKY = 50;
    elseif E >=60 && E <= 90
        TSKY = 30;
    end
elseif f > 30 && f <= 45
    if E >= 0 && E < 5
        TSKY = 295;
    elseif E >= 5 && E < 10
        TSKY = 220;
    elseif E >= 10 && E < 20
        TSKY = 150;
    elseif E >= 20 && E < 30
        TSKY = 90;
    elseif E >= 30 && E < 60
        TSKY = 70;
    elseif E >=60 && E <= 90
        TSKY = 40;
    end    
end

if E <= -10
    TGROUND = 290;
elseif E >-10 && E <= 0
    TGROUND = 150;
elseif E > 0 && E <= 10
    TGROUND = 50;
elseif E > 10 && E <= 90
    TGROUND = 10;
end

Tm = 275;   % mean thermodynamic temp of meteorological formations
% TF = 290;   % feeder temp

TA = 10*log10(TSKY/10^(Lrain/10)+Tm*(1-1/10^(Lrain/10))+TGROUND); 

% TeRX = 290;      %assume receiver temp = 50

T1 = 10*log10(TA+TF*(10^(LFRX/10)-1)+TeRX*10^(LFRX/10));

T = T1 - LFRX;

%Received noise power spectral density
%first evaluate clear sky performance

CtoN0 = 10*log10(PTX) + GTmax + GRmax - L - T - kdB;   %EIRP-tx, T-rx

end

