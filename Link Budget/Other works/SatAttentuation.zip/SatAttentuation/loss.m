function [ L Lrain LFRX A_ox A_wv A_cloud A_rain ] = loss( Long, lat, depolEarth, depolSat, earth3dB, satel3dB, polangel, LFEarthX, LFSatX, Elevation, transmission )
%loss function calculates the total loss(attennuation) of a satellite-earth link
%the arguments are: 
%1)l-latitude of earth station;
%2)L-relative longitude of the satellite w/ respect to the station;
%3)f-frequency; 
%4)D-Antenna diameter
%5)POLANGL-Polarization mismatch angle, angle between planes of receiving antenna &
%wave 
%5)TDA/RDA-Transmition/Reception depointing angles.
%
%   In this model, atmospheric loss is considered to be due to gaseous components
%   in the troposphere, water (e.g. rain, clouds, snow & ice), and also
%   includes losses due to the ionosphere. 

global R0 WL CR;                 %Global definitions

% ~~ Program ~~ %

CR = 1 + 0.42*(1-cosd(Long)*cosd(lat));             %Correction ratio (R/R0)^2

LFS = 10*log10((4*pi*R0/WL)^2*CR);                  %LFS in dB

L_earth = 12*(depolEarth/earth3dB)^2;
L_sat = 12*(depolSat/satel3dB)^2;         %in dB

if strcmpi(transmission, 'Uplink')
    LT = L_earth;
    LR = L_sat;
    LFTX = LFEarthX;
    LFRX = LFSatX;
elseif strcmpi(transmission, 'Downlink')
    LT = L_sat;
    LR = L_earth;
    LFTX = LFSatX;
    LFRX = LFEarthX;
else error('myApp:argChk', 'Transmission input must be either Uplink or Downlink')

end

LPOL = abs(20*log10(cosd(polangel)));

%to evaluate LA, we use:

[A_ox A_wv A_cloud A_rain] = atmAttenuation();

h = 0:0.0001:30;
Loxp = trapz(h,A_ox);

h = 0:0.0001:2;
Lwvp = trapz(h,A_wv);
Lrainp = trapz(h,A_rain);

h = 0:0.0001:0.36;
Lcloudp = trapz(h,A_cloud);

%assume rain to be 2km thick

Latmp = Loxp + Lwvp + Lrainp + Lcloudp;


Lrain = 10*log10(exp(Lrainp/sind(Elevation)));
LA = 10*log10(exp(Latmp/sind(Elevation)));  %atmospheric attenuation in dB

L(1) = LFS + LT + LR + LFTX + LFRX + LPOL + LA;
L(2) = LFS + LT + LR + LFTX + LFRX + LPOL;
L(3) = LFS + LT + LR + LFTX + LFRX;
L(4) = LFS + LT + LR;
L(5) = LFS;

return

end

